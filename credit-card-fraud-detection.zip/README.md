# Credit Card Fraud Detection

This project detects fraudulent transactions using machine learning. It uses a dataset of credit card transactions to train models that can classify whether a transaction is fraudulent or legitimate.

## Features

- Data preprocessing and visualization
- Handling class imbalance with SMOTE
- Model training using Logistic Regression, Random Forest, and XGBoost
- Performance evaluation with confusion matrix, ROC-AUC, etc.

## Usage

```bash
pip install -r requirements.txt
python main.py
```


from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
from src.preprocessing import load_and_preprocess_data

def train_and_evaluate_model():
    X_train, X_test, y_train, y_test = load_and_preprocess_data("data/creditcard.csv")
    model = LogisticRegression(max_iter=1000)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    print(classification_report(y_test, y_pred))
    print(confusion_matrix(y_test, y_pred))

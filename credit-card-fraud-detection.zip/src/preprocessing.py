import pandas as pd
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE

def load_and_preprocess_data(filepath):
    data = pd.read_csv(filepath)
    X = data.drop('Class', axis=1)
    y = data['Class']
    smote = SMOTE()
    X_res, y_res = smote.fit_resample(X, y)
    return train_test_split(X_res, y_res, test_size=0.2, random_state=42)

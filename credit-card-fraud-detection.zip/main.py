from src.model import train_and_evaluate_model

if __name__ == "__main__":
    train_and_evaluate_model()
